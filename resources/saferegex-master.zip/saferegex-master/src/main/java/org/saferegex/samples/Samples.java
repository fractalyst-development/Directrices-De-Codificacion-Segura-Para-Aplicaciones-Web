package org.saferegex.samples;

public interface Samples extends Iterable<String>{
    public int size();
    public boolean isEmpty();
}
