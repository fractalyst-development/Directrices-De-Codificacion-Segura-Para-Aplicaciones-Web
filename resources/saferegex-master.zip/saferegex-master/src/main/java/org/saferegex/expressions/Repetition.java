package org.saferegex.expressions;

public interface Repetition extends NestedExpression {
}