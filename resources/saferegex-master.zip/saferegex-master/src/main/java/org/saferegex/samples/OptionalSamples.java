package org.saferegex.samples;

public class OptionalSamples extends OptionSamples {
    boolean b = true;
    
    public OptionalSamples(Samples samples) {
        super(samples, new AtomSamples(""));
    }
}
