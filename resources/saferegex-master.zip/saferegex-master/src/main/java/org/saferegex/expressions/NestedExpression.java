package org.saferegex.expressions;

public interface NestedExpression extends Expression {

}
